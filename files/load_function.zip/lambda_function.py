import json
import os
# Import modules from neo4j library
from neo4j import GraphDatabase, basic_auth

def lambda_handler(event, context):
    # Retrieve the input from the event object
    input_data = event.get('extract_output')
    
    print('input_data', input_data)

    # Establish connection with neo4j database, mention your host, port, username & password(default port is 7687 and default host is localhost)
    driver = GraphDatabase.driver("bolt://localhost:7687", auth = basic_auth("subxander","$Miska2007"))
    # create a neo4j session in python
    session = driver.session()
    # store all the records(including nodes & relationships) in a list
    records = list(session.run("Match ((n)-[r]->(m)) return n,r,m"))

    print(records)
    
    return {
        'statusCode': 200,
        'body': input_data
    }
